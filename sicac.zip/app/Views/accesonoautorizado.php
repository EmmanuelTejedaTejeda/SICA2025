<style>
    div{
        height: 100%;
    }

    h1{
        display:flex;
        justify-content: center;
        align-items: center;
    }
</style>


<div>
    <h1>Acceso no autorizado</h1>
</div>