<?= $this->extend('template/main'); ?>

<?= $this->section('content'); ?>
<?php $validation = \Config\Services::validation(); ?>


<form method="POST" action="<?= base_url('admin/matriculaciones/update/' . $matriculado['id']); ?>"
    enctype="multipart/form-data">
    <?= csrf_field() ?>

    <div class="card primary">
        <div class="card-header">
            <h5 class="card-title d-inline">Actualizar datos de las grupo</h5>
            <h5 class="fw-bold d-inline">"<?= $matriculado['grups'] ?>"</h5>
        </div>

        <div class="card-body">

            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col d-flex">
                                    <h5 class="card-title d-inline">Estudiantes totales en el grupo: </h5>
                                    <h5 class="d-inline">
                                        <?= $matriculado['cantidadEstudiantes'] ?>
                                    </h5>
                                    <div class="ms-auto">
                                        <a class="btn btn-primary float-right" title="Ver" data-bs-toggle="modal"
                                            data-bs-target="#modalAgregarEstudiantes"
                                            data-grupo="<?= htmlspecialchars($matriculado['grups']) ?>">
                                            Agregar estudiantes
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <table id="ejample" class="table table-striped table-hovered table-bordered">
                                <thead>
                                    <th>Lista de estudiantes</th>
                                    <th class="d-flex justify-content-center">Acciones</th>
                                </thead>
                                <tbody>
                                    <?php $estudiantes = explode(', ', $matriculado['nombre_completo']); ?>
                                    <?php foreach ($estudiantes as $alumno): ?>
                                        <tr>
                                            <td>
                                                <?= $alumno ?>
                                            </td>
                                            <td class="d-flex justify-content-center">
                                                <form class="display-none" method="post"
                                                    action="<?= base_url('admin/matriculaciones/deleteAlumno/' . $matriculado['id']) ?>"
                                                    id="matriculacionDeleteForm<?= $matriculado['id'] ?>">
                                                    <input type="hidden" />
                                                    <a href="javascript:void(0)"
                                                        onclick="eliminarElemento('matriculacionDeleteForm<?= $matriculado['id'] ?>', '¿Desea eliminar al alumno del grupo seleccionado? Esta acción es irreversible.')"
                                                        class="btn btn-default" title="Eliminar">
                                                        <i class="fas fa-trash text-danger"></i></a>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <th>Lista de estudiantes</th>
                                    <th class="d-flex justify-content-center">Acciones</th>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>

            </div>

            <div class="card-footer text-end">
                <button type="submit" class="btn btn-primary float-right">Actualizar</button>
                <a href="<?= base_url('admin/matriculaciones') ?>" class="btn btn-danger">Cancelar y regresar</a>
            </div>

        </div>
</form>

<!--MODAL-->
<div class="modal fade modal-lg modal-dialog-scrollable" id="modalAgregarEstudiantes" data-bs-backdrop="static"
    data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalAgregarEstudiantes" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5 d-inline" id="staticBackdropLabel">Agregar alumnos al grupo <p
                        class="d-inline fw-bold" id="nombre_grupo">
                        </>
                </h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row align-items-start">
                    <div class="col">
                        <p class="fs-6 fw-bold">Estudiantes:</p>
                        <?php foreach ($usuarios as $usuario): ?>
                            <div>
                                <ul>
                                    <li>
                                        <input type="checkbox" name="estudiantes[]" value="<?= $usuario['id_usuario'] ?>">
                                        <?= $usuario['nombre_alumnos'] ?>
                                    </li>
                                </ul>
                            </div>

                        <?php endforeach; ?>
                    </div>
                    <div class="col">
                        <p class="fs-6 fw-bold">Grupo al que pertenecen:</p>
                        <?php foreach ($usuarios as $usuario): ?>
                            <div>
                                <?php if ($usuario['nombre_grupo'] != 'No asignado'): ?>
                                    <p><?= $usuario['nombre_grupo'] ?></p>
                                <?php else: ?>
                                    <p>Este estudiante no pertenece a ningún grupo.</p>
                                <?php endif; ?>
                            </div>

                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                <button type="button" class="btn btn-primary" id="guardarCambios">Guardar cambios</button>
            </div>



        </div>
    </div>
</div>

<?= $this->endSection(); ?>