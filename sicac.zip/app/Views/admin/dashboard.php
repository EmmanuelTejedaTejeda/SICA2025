<?= $this->extend('template/main'); ?>

<?= $this->section('content'); ?>
<?= $this->endSection(); ?>