<form action="<?= base_url('admin/carreras') ?>" method="post">

	<div>
		<label for="">Clave de carrera:</label>
		<input type="text" name="clave" id="">
	</div>
	<div>
		<label for="">Carrera:</label>
		<input type="text" name="nombre" id="">
	</div>
	<div>
		<input type="submit" value="Guardar">
	</div>

</form>