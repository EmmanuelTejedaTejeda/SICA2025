<?php

namespace App\Controllers\Admin;

use CodeIgniter\RESTful\ResourceController;
use App\Models\GrupoModel;
use App\Models\GrupocpeModel;

class GrupoController extends ResourceController
{
    private $GrupoModel;
    private $grupocpe;
    public function __construct()
    {
        helper('form');
        $this->grupoModel = new GrupoModel();
        $this->grupocpe = new GrupocpeModel();
    }
    
    public function consulta(){
        $conexion = \Config\Database::connect();
        return $conexion->query('
            SELECT gcpe.id,
            concat(pa.clave,"-", substring(c.clave, 1, 4),"-",g.grupo) as grupo
            from grupocpe as gcpe
            join grupos as g on gcpe.grupos = g.id 
            join periodo_academico as pa on pa.id = gcpe.periodoEscolar  
            join carreras as c on gcpe.carrera = c.id'
        );
    }

    public function index()
    {
        /*
        $grupos = $this->grupoModel->orderBy('id', 'desc')->findAll();
        $data = [
            'grupos' => $grupos
        ];
        if (session()->get('perfil') == 1) {
            return view('admin/grupos/index', $data);
        } else if (session()->get('perfil') == 2) {
            return view('asesor/grupos/index', $data);
        } elseif (session()->get('perfil') == 3) {
            return view('estudiante/grupos/index', $data);
        }
        */

        $conexion = \Config\Database::connect();
        $grupos = $conexion->query(
            'SELECT gcpe.id,
            concat(pa.clave,"-", substring(c.clave, 1, 4),"-",g.grupo) as grupo
            from grupocpe as gcpe
            join grupos as g on gcpe.grupos = g.id 
            join periodo_academico as pa on pa.id = gcpe.periodoEscolar  
            join carreras as c on gcpe.carrera = c.id'
            )->getResultArray();
            

        $data = [
            'grupocpe' => $grupos
        ];
        if (session()->get('perfil') == 1) {
            return view('admin/grupos/index', $data);
        } else if (session()->get('perfil') == 2) {
            return view('asesor/grupos/index', $data);
        } elseif (session()->get('perfil') == 3) {
            return view('estudiante/grupos/index', $data);
        }
    }


    

    public function show($id = null)
    {
        //
    }


    

    public function new()
    {
        //
    }


    

    public function create()
    {
        //
    }


    

    public function edit($id = null)
    {
        //
    }


    

    public function update($id = null)
    {
        //
    }


    

    public function delete($id = null)
    {
        //
    }
    public function agregarAsignaturas($id = null){
        $grupo = $this->grupocpe->find($id);
        //return view('admin/grupos/agregarAsignaturas', compact('grupo'));

        dd($grupo);
    }
}
